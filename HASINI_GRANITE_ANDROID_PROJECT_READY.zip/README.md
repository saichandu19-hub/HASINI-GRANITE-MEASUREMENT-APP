# HASINI GRANITE MEASUREMENT SHEET — Android APK build

This ZIP uses the original `hasini-granite-full-hd.png` artwork for the Android launcher icon. The icon is included in the web assets and resized for Android launcher densities.

## Important
- The ZIP has no extra outer project folder: extract it and the project files appear immediately.
- Android Gradle requires the internal `app/src/main/...` and `.github/workflows/` directories. Do not flatten or rename those internal paths.
- Do not delete the existing GitHub Pages web files in your current repository.

## Build APK using GitHub Actions
1. Extract this ZIP.
2. In your GitHub repository, upload the project files/folders from the extracted ZIP to the repository root, preserving their paths. Merge with existing files; do not remove `index.html`, `manifest.json`, icons, or `sw.js` at the repository root.
3. Commit the upload.
4. Open **Actions** and select **Build HASINI Android APK**. If it appears, tap **Run workflow**.
5. Wait for the run to finish successfully, then open its **Artifacts** section and download the APK artifact.

A successful build has not been produced by this ZIP itself; GitHub Actions must run to create the installable APK.
