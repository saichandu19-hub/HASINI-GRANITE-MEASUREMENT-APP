HASINI GRANITE MEASUREMENT SHEET — Android యాప్ ప్రాజెక్ట్

ఇది Chromeలో వెబ్‌సైట్ తెరిచే షార్ట్‌కట్ కాదు. HTML ఫైల్ యాప్‌లోనే ఉంచబడింది; యాప్ Full Screenలో, Browser Address Bar లేకుండా తెరుచుకుంటుంది.

సంతకం చేసిన APK తయారీకి:
1. ZIP ఫైల్‌ను డౌన్‌లోడ్ చేసి Extract చేయండి.
2. కంప్యూటర్‌లో Android Studio ఇన్‌స్టాల్ చేసి ఈ ఫోల్డర్‌ను Open చేయండి.
3. Gradle Sync పూర్తయ్యే వరకు వేచి ఉండండి; అవసరమైతే Android SDK Platform 35 ఇన్‌స్టాల్ చేయండి.
4. Build > Generate Signed Bundle / APK ఎంచుకోండి.
5. APK ఎంచుకుని Next నొక్కండి.
6. Create new keystore ద్వారా మీరే keystore, password సృష్టించండి. వాటిని సురక్షితంగా భద్రపరచండి.
7. release ఎంచుకుని Finish నొక్కండి. Android Studio signed APK ఫైల్ స్థానాన్ని చూపిస్తుంది.

ముఖ్య గమనిక: ఇక్కడ Android SDK/Gradle build tools లేనందున సంతకం చేసిన APK ఫైల్‌ను నేరుగా తయారు చేయలేదు. ఇది Android Studio project మాత్రమే; నిజమైన ఫోన్‌లో compile/test చేయలేదు. Keystore లేదా password ఎవరితోనూ పంచుకోవద్దు.

GitHub Actions బిల్డ్: repository root లోని అన్ని ఫైళ్లు/ఫోల్డర్లు అప్‌లోడ్ చేయాలి. ముఖ్యంగా app/ ఫోల్డర్ తప్పనిసరి. build.gradle అనేది root ఫైల్; app/build.gradle వేరే ఫైల్. రెండింటిని కలపకండి.
